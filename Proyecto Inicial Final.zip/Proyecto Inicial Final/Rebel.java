
/**
 * Rueda que no se puede borrar, cambiar o bloquear
 * 
 * @author Juan Esteban Mendoza, Omar Santiago Perez
 * @version 1.0 (24 de octubre de 2026)
 */
public class Rebel extends Wheel{
    /**
     * El constructor de la rueda
     * @param num el numero que le corresponde a la rueda
     */
    public Rebel(int num){
        super(num);
        type="rebel";
        body.changeColor("black");
    }
}
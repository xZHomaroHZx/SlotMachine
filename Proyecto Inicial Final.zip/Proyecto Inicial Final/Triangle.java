import java.awt.*;

/**
 * A triangle that can be manipulated and that draws itself on a canvas.
 * 
 * @author  Michael Kolling and David J. Barnes
 * @version 1.0  (15 July 2000)
 */

public class Triangle extends Figure{
    public final static int VERTICES=3;
    private int height;
    private int width;
    private float area;
    

    /**
     * Create a new triangle at default position with default color.
     */
    public Triangle(){
        height = 30;
        width = 30;
        xPosition = 0;
        yPosition = 0;
        color = "green";
        isVisible = false;
    }
    
    /**
     * Create a new triangle at default position with default color.
     */
    public Triangle(String color, int xPosition, int yPosition){
        height = 30;
        width = 40;
        this.xPosition = xPosition;
        this.yPosition = yPosition;
        this.color = color;
        isVisible = false;
    }

    /**
     * Gives us the triangle area.
     */
    public float area(){
        if (height< 0 ^ width< 0){
            area=-(height*width)/2;
        }
        else{
            area=(height*width)/2;
        }
        //Lo que sigue puede o no ser parte del codigo o no (solo
        //deberia retornarla pero para que haya una prueba)
        System.out.println(area);
        return area;
    }
    
    /**
     * Makes the triangle equilateral
     */
    public void equilateral(){
        if ((height<0 && width>0) || (height>0 && width<0)){
        height=-(int)(width*0.87);
        }
        else{
        height=(int)(width*0.87);
        }
        changeSize(height, width);
    }
    
    

    /**
     * Change the size to the new size
     * @param newHeight the new height in pixels. newHeight must be >=0.
     * @param newWidht the new width in pixels. newWidht must be >=0.
     */
    public void changeSize(int newHeight, int newWidth) {
        erase();
        if (newHeight==0){
            height=1;
            width=newWidth;
        }
        else{
            height = newHeight;
            width = newWidth;
        }
        draw();
    
    }
    
    public int[] getMeasures(){
        int [] measures=new int[2];
        measures[0]=height;
        measures[1]=width;
        return measures;
    }
    

    /**
     * Draw the triangle with current specifications on screen.
     */
    @Override
    protected void draw(){
        if(isVisible) {
            Canvas canvas = Canvas.getCanvas();
            int[] xpoints = { xPosition, xPosition + (width/2), xPosition - (width/2) };
            int[] ypoints = { yPosition, yPosition + height, yPosition + height };
            canvas.draw(this, color, new Polygon(xpoints, ypoints, 3));
            canvas.wait(10);
        }
    }

    /**
     * Erase the triangle on screen.
     */
    @Override
    protected void erase(){
        if(isVisible) {
            Canvas canvas = Canvas.getCanvas();
            canvas.erase(this);
        }
    }
    
    public String getColor(){
        return color;
    }
}

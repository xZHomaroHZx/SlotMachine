import java.util.ArrayList;
import java.util.Random;
import javax.swing.JOptionPane;
/**
 * La clase principal del proyecto
 * 
 * @author  Juan Esteban Mendoza Acero, Omar Santiago Perez
 * @version 5.0  (24 de octubre 2026)
 */
public class SlotMachine {
    private boolean ok;
    private boolean isVisible;
    private Rectangle base;
    private ArrayList<Wheel> wheels;
    private Random random;
    private int rows;
    private int columns;
    private CSSColors colors;
    /**
     * Inicializa la máquina con 3 ruedas (con simbolos estandares) y en estado invisible.
     */
    public SlotMachine(){
        isVisible=false;
        base=new Rectangle();
        base.changeColor("red");
        base.changeSize(300, 550);
        wheels=new ArrayList<Wheel>();
        random=new Random();
        rows=1;
        columns=3;
        for (int i=0; i<3; i++){
        wheels.add(new Wheel(i+1));
        wheels.get(i).addSymbol("blue");
        wheels.get(i).addSymbol("magenta");
        wheels.get(i).addSymbol("yellow");
        }
        //makeVisible();
        ok=true;
    }

    /**
     * Inicializa la maquina con n ruedas al azar (con n simbolos al azar (pero compartidos entre todos)
     * @param n el numero de ruedas/simbolos
     */
    public SlotMachine(int n){
        if (n<3){
                n=3;
            }
            else if (n>50){
                n=50;
            }
        isVisible=false;
        base=new Rectangle();
        base.changeColor("red");
        base.changeSize(300,550);
        wheels=new ArrayList<Wheel>();
        random=new Random();
        colors=new CSSColors();
        rows=1;
        columns=0;
        for (int i=1; i<=n; i++){ //n ruedas nuevas
            addWheel(i);
        }
        ArrayList<String> available=new ArrayList<String>(); //colores disponibles para los Random
        for (String color: colors.getColors()){
            available.add(color); //los añadimos en un ArrayList por facilidad
        }
        int availableColors=available.size();
        for (int i=0; i<n; i++){//n colores al azar
            int position=random.nextInt(availableColors);
            String color=available.get(position);
            for (int j=0; j<wheels.size(); j++){
                wheels.get(j).addSymbol(color);
            }
            available.remove(position); //eliminamos el que salio
            availableColors-=1;
        }
        ok=true;
        spin();
    }

    /**
     * Añade una rueda en una posicion deseada (si es menor a la actual da 1 y si es mayor da la ultima) y recalcula el numero de las ruedas
     * 
     * @param  pos  la posicion deseada de la rueda
     */
    public void addWheel(int pos){
        if (wheels.size()<50){
            if (pos<1){
                pos=1;
            }
            else if (pos>wheels.size()+1){
                pos=wheels.size()+1;
            }
            Wheel newWheel=new Wheel(pos);
            wheels.add(pos-1,newWheel);
            for (int i=pos; i<wheels.size(); i++){
                wheels.get(i).setNumber(wheels.get(i).getNumber()+1);
            }
            if (columns<8){
                columns+=1;
            }
            else {
                rows=(wheels.size()/8)+1;
            }
            reshape();
            if (isVisible){
                newWheel.makeVisible();
            }
            ok=true;
        }
        else{
            ok=false;
            JOptionPane.showMessageDialog(null, "SlotMachine solo admite 50 Wheels.", "Error", JOptionPane.ERROR_MESSAGE);
        }
    }
    
    /**
     * Añade una rueda de un tipo especifico
     * @param type el tipo de rueda (normal, rebel, lefty o rainbow)
     */
    public void addWheel(String type, int pos){
        if (wheels.size()<50){
            Wheel newWheel=null;
            if (type.equals("normal")){
                newWheel=new Wheel(pos);
            }
            else if (type.equals("lefty")){
                newWheel=new Lefty(pos);
            }
            else if (type.equals("rebel")){
                newWheel=new Rebel(pos);
            }
            else if (type.equals("rainbow")){
                newWheel=new Rainbow(pos);
            }
            if (newWheel!=null){
                if (pos<1){
                    pos=1;
                }
                else if (pos>wheels.size()+1){
                    pos=wheels.size()+1;
                }
                newWheel.setNumber(pos);
                wheels.add(pos-1,newWheel);
                for (int i=pos; i<wheels.size(); i++){
                    wheels.get(i).setNumber(wheels.get(i).getNumber()+1);
                }
                if (columns<8){
                    columns+=1;
                }
                else{
                    rows=(wheels.size()/8)+1;
                }
                reshape();
                if (isVisible){
                    newWheel.makeVisible();
                }
                ok=true;
            }
            else{
                ok=false;
                JOptionPane.showMessageDialog(null, "Tipo de rueda no valido.", "Error", JOptionPane.ERROR_MESSAGE);
            }
        }
        else{
            ok=false;
            JOptionPane.showMessageDialog(null, "SlotMachine solo admite 50 Wheels.", "Error", JOptionPane.ERROR_MESSAGE);
        }
    }
    
    /**
     * Reforma la base (para que las nuevas ruedas quepan)
     * Caben 8 ruedas en una fila 
     */
    private void reshape(){
        int size= wheels.size();
        if (size!=50){
            int height=100+100*rows;
            int width=50+175*columns;
            base.changeSize(height, width);
        }
        for (int i=0; i<size; i++){
            int row=i/8;
            int column=i%8;
            int x=100+175*column;
            int y=50+105*row;
            wheels.get(i).moveTo(x,y);
        }
    }
    
    
    /**
     * Elimina la rueda en la posicion deseada y recalcula los numeros de las ruedas despues
     * 
     * @param  pos  la posicion de la rueda a eliminar
     */
    public void delWheel(int pos){
        if (wheels.size()>0){
            if (pos<1){
                pos=1;
            }
            else if (pos>wheels.size()){
                pos=wheels.size();
            }
            Wheel selectedWheel=wheels.get(pos-1);
            if (!selectedWheel.getType().equals("rebel")){
                selectedWheel.makeInvisible();
                wheels.remove(pos-1);
                for (int i=pos-1; i<wheels.size(); i++){
                    wheels.get(i).setNumber(wheels.get(i).getNumber()-1);
                }
                if (columns>1 && wheels.size()<8){
                    columns=columns-1;
                }
                else{
                    columns=8;
                    rows=(wheels.size()/8)+1;
                }
                reshape();
                ok=true;
            }
            else{
                ok=false;
                JOptionPane.showMessageDialog(null, "No se puede borrar una rueda rebelde.", "Error", JOptionPane.ERROR_MESSAGE);
            }
        }
        else{
            ok=false;
            JOptionPane.showMessageDialog(null, "No hay wheels por borrar.", "Error", JOptionPane.ERROR_MESSAGE);
        }
    }


    /**
     * Añade un nuevo simbolo en una rueda especifica y de un color especifico
     * 
     * @param  pos  la posicion de la rueda en la que se desea añadir el simbolo
     * @param color el color del simbolo nuevo
     */
    public void addSymbol(int pos, String color){
        if (wheels.size()>0){
            if (pos<1){
                pos=1;
            }
            else if (pos>wheels.size()){
                pos=wheels.size();
            }
            if (wheels.get(pos-1).getLocked()){
                ok=false;
                JOptionPane.showMessageDialog(null, "La rueda esta bloqueada.", "Error", JOptionPane.ERROR_MESSAGE);
            }
            else if (wheels.get(pos-1).addSymbol(color)){
                ok=true;
            }
            else{
                ok=false;
                JOptionPane.showMessageDialog(null, "Ya existe ese simbolo.", "Error", JOptionPane.ERROR_MESSAGE);
            }
        }
        else{
            ok=false;
            JOptionPane.showMessageDialog(null, "Intentaste añadir un simbolo cuando no hay ruedas.", "Error", JOptionPane.ERROR_MESSAGE);
        }
    }
    
    /**
     * Añade un simbolo de un tipo a una rueda en especifico
     * @param type tipo del simbolo (normal, shy o ephemeral)
     * @param color el color del simbolo
     * @param pos la rueda donde se quiere poner
     */
    public void addSymbol(String type, String color, int pos){
        if (wheels.size()>0){
            if (pos<1){
                pos=1;
            }
            else if (pos>wheels.size()){
                pos=wheels.size();
            }
            if (wheels.get(pos-1).getLocked()){
                ok=false;
                JOptionPane.showMessageDialog(null, "La rueda esta bloqueada.", "Error", JOptionPane.ERROR_MESSAGE);
            }
            else if (wheels.get(pos-1).addSymbol(type,color)){
                ok=true;
            }
            else{
                ok=false;
                JOptionPane.showMessageDialog(null, "No se pudo añadir el simbolo.", "Error", JOptionPane.ERROR_MESSAGE);
            }
        }
        else{
            ok=false;
            JOptionPane.showMessageDialog(null, "Intentaste añadir un simbolo cuando no hay ruedas.", "Error", JOptionPane.ERROR_MESSAGE);
        }
    }

    /**
     * Elimina un simbolo especifico de todas las ruedas
     * 
     * @param symbol    el simbolo a eliminar
     */
    public void delSymbol(String symbol){
        if (wheels.size()>0){
            for (int i=0; i<wheels.size(); i++){
                wheels.get(i).delSymbol(symbol);
            }
            ok=true;
        }
        else{
            ok=false;
            JOptionPane.showMessageDialog(null, "No hay ruedas para borrar un simbolo", "Error", JOptionPane.ERROR_MESSAGE);
        }
    }


    /**
     * Pone una rueda en el simbolo deseado
     * 
     * @param   wheel   la rueda en que se quiere girar
     * @param   symbol  el simbolo que se quiere dejar
     */
    public void placeSymbol(int wheel, String symbol){
        if (wheel>=1 && wheel<=wheels.size()){
            if (wheels.get(wheel-1).getLocked()){
                ok=false;
                JOptionPane.showMessageDialog(null, "La rueda esta bloqueada", "Error", JOptionPane.ERROR_MESSAGE);
            }
            else if (wheels.get(wheel-1).placeSymbol(symbol)){
                ok=true;
            }
            else{
                ok=false;
                JOptionPane.showMessageDialog(null, "El simbolo que indicaste no esta en la rueda", "Error", JOptionPane.ERROR_MESSAGE);
            }
        }
        else{
            ok=false;
            JOptionPane.showMessageDialog(null, "Elegiste una rueda que no esta (se especifico con la rueda)", "Error", JOptionPane.ERROR_MESSAGE);
        }
    }

    /**
     * Gira solo una rueda especifica
     * 
     * @param   wheel   la rueda que se quiere girar (aca si especificar la que se desea)
     */
    public void spin(int wheel){
        if (wheels.size()>0){
            if (wheel<1){
                wheel=1;
            }
            else if (wheel>wheels.size()){
                wheel=wheels.size();
            }
            Wheel selectedWheel=wheels.get(wheel-1);
                if (!selectedWheel.getLocked()){
                try{
                    if (selectedWheel.getType().equals("lefty")){
                        if (wheel>1){
                            ((Lefty)selectedWheel).spinRandom(wheels.get(wheel-2));
                        }
                        else{
                            selectedWheel.spinRandom();
                        }
                    }
                    else{
                        selectedWheel.spinRandom();
                    }
                    ok=true;
                }
                catch (SlotMachineException e){
                    ok=false;
                    JOptionPane.showMessageDialog(null, e.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
                }
            }
            else{
                ok=false;
                JOptionPane.showMessageDialog(null, SlotMachineException.WHEEL_LOCKED, "Error", JOptionPane.ERROR_MESSAGE);
            }
        }
        else{
            ok=false;
            JOptionPane.showMessageDialog(null, SlotMachineException.NO_WHEELS_TO_SPIN, "Error", JOptionPane.ERROR_MESSAGE);
        }
    }

    /**
     * Gira todas las ruedas de la maquina (no falla si una esta bloqueada)
     * 
     */
    public void spin(){
        if (wheels.size()>0){
            boolean possible=true;
            for (int i=0; i<wheels.size(); i++){
                if (!wheels.get(i).getLocked() && wheels.get(i).getSymbols().size()==0){
                    possible=false;
                }
            }
            if (possible){
                try{
                    for (int i=0; i<wheels.size(); i++){
                        Wheel selectedWheel=wheels.get(i);
                        if (!selectedWheel.getLocked()){
                            if (selectedWheel.getType().equals("lefty") && i>0){
                                ((Lefty) selectedWheel).spinRandom(wheels.get(i-1));
                            }
                            else{
                                selectedWheel.spinRandom();
                            }
                        }
                    }
                    ok=true;
                    isJackpot();
                }
                catch (SlotMachineException e){
                    ok=false;
                    JOptionPane.showMessageDialog(null, e.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
                }
            }
            else{
                ok=false;
                JOptionPane.showMessageDialog(null, "No se pudo completar, alguna rueda no tiene simbolos", "Error", JOptionPane.ERROR_MESSAGE);
            }
            }
        else{
            ok=false;
            JOptionPane.showMessageDialog(null, "No hay ruedas para girar", "Error", JOptionPane.ERROR_MESSAGE);
        }
    }


    /**
     * Retorna los colores disponibles de los simbolos y sin repetirlos
     * 
     * @return     la lista con los colores
     */
    public String[] symbols(){
        String[] result=new String[148]; //maximo de colores
        int count=0; //contar para hacer un String[] que no muestre nulls
        for (int i=0; i<wheels.size(); i++){
            ArrayList<Symbol> current=wheels.get(i).getSymbols();
               for (int j=0; j<current.size(); j++){
                String color=current.get(j).getColor();
                boolean exists=false;
                for (int k=0;k<count;k++){
                    if (result[k].equals(color)){
                        exists=true; //ya estaba, no deberia contar
                    }
                }
                if (!exists){ //si no existe lo añade
                    result[count]=color;
                    count=count+1;
                }
            }
        }
        String[] finalResult=new String[count]; //hace el String[] con tamaño correcto
        for (int i=0;i<count;i++){
            finalResult[i]=result[i];
        }
        return finalResult;
    }

    /**
     * Retorna la cantidad de simbolos diferentes (de actualSymbol's)
     *
     * @return     el numero de simbolos diferentes
     */
    public int distinctSymbols(){
        ArrayList<String> different=new ArrayList<String>();
        try{
            for (int i=0; i<wheels.size(); i++){
                String current=wheels.get(i).getCurrentSymbol();
                if (!different.contains(current)){
                    different.add(current);
                }
            }
        }
        catch(SlotMachineException e){
            ok=false;
            JOptionPane.showMessageDialog(null, e.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
        }
        return different.size();
    }

    /**
     * Retorna los simbolos de las ruedas de la numero 1 hasta la final
     *
     * @return     la lista con todos los simbolos
     */
    public String[] configuration(){
        String[] result=new String[wheels.size()];
        try{
            for (int i=0; i<wheels.size(); i++){
                result[i]=wheels.get(i).getCurrentSymbol();
            }
        }
        catch(SlotMachineException e){
            ok=false;
            JOptionPane.showMessageDialog(null, e.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
        }
        return result;
    }


    /**
     * Retorna true si todos los simbolos actuales de las ruedas son el mismo
     * 
     * @return     booleano que dice si fue o no un jackpot
     */
    public boolean isJackpot(){
        boolean jackpot=true;
        if (wheels.size()>0){
            try{
            String first=wheels.get(0).getCurrentSymbol();
            for (int i=1; i<wheels.size(); i++){
                    if (!first.equals(wheels.get(i).getCurrentSymbol())){
                        jackpot=false;
                    }
            }
            }
            catch(SlotMachineException e){
                jackpot=false;
                ok=false;
                JOptionPane.showMessageDialog(null, e.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
            }
        }      
        if (jackpot){
            base.changeColor("green"); //por default es jackpot (cuando no hay ruedas)
        }
        else{
            base.changeColor("red");
        }
        reshape(); //para que no se vea solo la base
        return jackpot;
        //era mejor usar distinctSymbols() y ver si era 1?
    }


    /**
     * Hace visible el simulador
     * 
     */
    public void makeVisible(){
        isVisible=true;
        base.makeVisible();
        for (Wheel wheel: wheels){ 
            wheel.makeVisible();
        }
    }

    /** 
     * Oculta el simulador (aun funciona)
     *  
     */
    public void makeInvisible(){
        isVisible=false;
        base.makeInvisible();
        for (Wheel wheel: wheels){
            wheel.makeInvisible();
        }
    }


    /** 
     * Termina la ejecución del simulador. 
     * 
     */
    public void exit(){
        System.exit(0);
    }
    

    /**
     * Regresa si se pudo hacer la ultima operacion
     * 
     * @return     el booleano que indica si se pudo hacer la operacion o no
     */
    public boolean ok(){
        return ok;
    }
    
    /**
     * Intercambia dos ruedas.
     *
     * @param wheel1 la primera rueda
     * @param wheel2 la segunda rueda
     */
    public void swap(int wheel1,int wheel2){
        if (wheels.size()>0){
            if (wheel1<1){ //revision usual de si alguna es mayor a wheelCount o menor a 1
                wheel1=1;
            }
            else if (wheel1>wheels.size()){
                wheel1=wheels.size();
            }
            if (wheel2<1){
                wheel2=1;
            }
            else if (wheel2>wheels.size()){
                wheel2=wheels.size();
            }
            if ((wheels.get(wheel1-1).getLocked() || wheels.get(wheel2-1).getLocked()) || (wheels.get(wheel1-1).getType().equals("rebel") || wheels.get(wheel2-1).getType().equals("rebel"))){ //si no esta alguna bloqueada o alguna es rebel
                ok=false;
                JOptionPane.showMessageDialog(null, "Una de las ruedas esta bloqueada o es rebelde.", "Error", JOptionPane.ERROR_MESSAGE);
            }
            else{ //el cambio (si todo esta bien)
                Wheel first=wheels.get(wheel1-1);
                Wheel second=wheels.get(wheel2-1);
                int[] coordinate1=first.getCoordinates();
                int[] coordinate2=second.getCoordinates();
                first.setNumber(wheel2);
                second.setNumber(wheel1);
                first.moveTo(coordinate2[0],coordinate2[1]);
                second.moveTo(coordinate1[0],coordinate1[1]);
                wheels.set(wheel1-1,second);
                wheels.set(wheel2-1,first);
                reshape();
                ok=true;
            }
        }
        else{
            ok=false;
            JOptionPane.showMessageDialog(null, "No hay ruedas que cambiar (0)", "Error", JOptionPane.ERROR_MESSAGE);
        }
    }
    
    /**
     * Bloquea la rueda que se diga (sigue usanda la primera si es menor a 1 y ultima si es mayor a wheelCount
     *a
     * @param wheel la rueda a bloquear
     */
    public void lock(int wheel){
        if (wheels.size()>0){
            if (wheel<1){
                wheel=1;
            }
            else if (wheel>wheels.size()){
                wheel=wheels.size();
            }
            Wheel selectedWheel=wheels.get(wheel-1);
            if (!selectedWheel.getType().equals("rebel")){
                selectedWheel.lock();
                ok=true;
            }
            else{
                ok=false;
                JOptionPane.showMessageDialog(null, SlotMachineException.REBEL_CANNOT_BE_LOCKED, "Error", JOptionPane.ERROR_MESSAGE);
            }
        }
        else{
            ok=false;
            JOptionPane.showMessageDialog(null, SlotMachineException.NO_WHEELS_TO_LOCK, "Error", JOptionPane.ERROR_MESSAGE);
        }
    }
    
    /**
     * Desbloquea la rueda especificada (mismo criterio que lock)
     *
     * @param wheel la rueda a desbloquear
     */
    public void unlock(int wheel){
        if (wheels.size()>0){
            if (wheel<1){
                wheel=1;
            }
            else if (wheel>wheels.size()){
                wheel=wheels.size();
            }
            wheels.get(wheel-1).unlock();
            ok=true;
        }
        else{
            ok=false;
            JOptionPane.showMessageDialog(null, "No hay ruedas por desbloquear.", "Error", JOptionPane.ERROR_MESSAGE);
        }
    }
    
    /**
     * Gira una rueda una cantidad de pasos. (no elije rueda por ti si es mayor a wheelCount o menor a 1)
     * Acepta negativos
     *
     * @param wheel la rueda que se quiere girar
     * @param steps cantidad de posiciones que se quiere avanzar o retroceder
     */
    public void spin(int wheel,int steps){
        if (wheel>=1 && wheel<=wheels.size()){
            Wheel selectedWheel=wheels.get(wheel-1);
            if (!selectedWheel.getLocked()){
                try{
                    if (selectedWheel.getType().equals("lefty")){//si es lefty es diferente
                        if (wheel>1){
                            Lefty lefty=(Lefty)selectedWheel; //castear como Lefty para que sepa a que metodo referirise (los spin normal de Wheel no tienen una rueda de referencia)
                            Wheel leftWheel=wheels.get(wheel-2);
                            if (isVisible){
                                if (steps>0){
                                    lefty.spinVisible(leftWheel,steps);
                                }
                                else{
                                    lefty.spinVisibleBack(leftWheel,steps);
                                }//aca de podian ser el mismo (son exactamente el mismo resultado) pero para dejarlo como los otros
                            }
                            else{
                                lefty.spinInvisible(leftWheel,steps);
                            }
                        }
                        else{ //es lefty pero va de primero (no tiene rueda a su izquierda) (entonces lo hace normal)
                            if (isVisible){
                                if (steps>0){
                                    selectedWheel.spinVisible(steps);
                                }
                                else if (steps<0){
                                    selectedWheel.spinVisibleBack(-steps);
                                }
                            }
                            else{
                                selectedWheel.spinInvisible(steps);
                            }
                        }
                    }
                    else{
                        if (isVisible){
                            if (steps>0){
                                selectedWheel.spinVisible(steps);
                            }
                            else if (steps<0){
                                selectedWheel.spinVisibleBack(-steps);
                            }
                        }
                        else{
                            selectedWheel.spinInvisible(steps);
                        }
                    }
                    ok=true;
                }
                catch (SlotMachineException e){
                    ok=false;
                    JOptionPane.showMessageDialog(null, e.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
                }
            }
            else{
                ok=false;
                JOptionPane.showMessageDialog(null, SlotMachineException.WHEEL_LOCKED, "Error", JOptionPane.ERROR_MESSAGE);
            }
        }
        else{
            ok=false;
            JOptionPane.showMessageDialog(null, "Rueda no valida (<1 o >wheelCount).", "Error", JOptionPane.ERROR_MESSAGE);
        }
    }
    
    /**
     * Establece una configuracion especifica para todas las ruedas (debe una para todas las ruedas)
     * Para probar toca con "new String[]{"a", "b"}" si fueran 2 ruedas y ademas a y b fueran colores
     *
     * @param configuration los colores que debe tener cada rueda
     */
    public void spin(String[] configuration){
        if (configuration.length==wheels.size()){
            boolean possible=true;//revisa primero si es posible que los cambios ocurran (si una rueda no tiene un color que deberia fallara)
            try{
                for (int i=0; i<wheels.size(); i++){
                    boolean found=false;
                    for (int j=0; j<wheels.get(i).getSymbols().size(); j++){
                        if (wheels.get(i).getSymbols().get(j).getColor().equals(configuration[i])){ //preguntar para secuencia
                            found=true;
                        }
                    }
                    if (!found){
                        possible=false;
                    }
                    if (wheels.get(i).getLocked()){
                        if (!wheels.get(i).getCurrentSymbol().equals(configuration[i])){
                            possible=false;
                        }
                    }
                }
            }
            catch(SlotMachineException e){
                ok=false;
                JOptionPane.showMessageDialog(null, e.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
            }
            //ahora que reviso que todas pueden hacer los cambios y los hace
            if (possible){
                for (int i=0;i<wheels.size();i++){
                    wheels.get(i).placeSymbol(configuration[i]);
                }
                ok=true;
            }
            else{
                ok=false;
                JOptionPane.showMessageDialog(null, "No es posible hacer esa configuracion, alguna rueda no tiene el simbolo especificado o esta bloqueada.", "Error", JOptionPane.ERROR_MESSAGE);
            }
        }
        else{
            ok=false;
            JOptionPane.showMessageDialog(null, "Faltan parametros para configurar todo.", "Error", JOptionPane.ERROR_MESSAGE);
        }
    }
}

/**
 * Un simbolo que aparece y desaparace cuando es seleccionado (tiene un borde para distinguir de una rueda vacia)
 * 
 * @author Juan Esteban Mendoza Acero, Omar Santiago Perez
 * @version 1.0 (24 de octubre 2026)
 */
public class Shy extends Symbol{
    private boolean isShy;
    private Triangle border;
    private String original;
    /**
     * Constructor del simbolo shy
     * @param color el color del simbolo
     * @xPosition la posicion que le corresponde en eje x
     * @yPosition la posicion que le corresponde en eje y
     */
    public Shy(String color, int xPosition, int yPosition){
        super(color, xPosition, yPosition);
        isShy=false;
        original=color;
        border=new Triangle();
        border.changeSize(34, 34);
        border.moveHorizontal(coordinate[0]+34);
        border.moveVertical(coordinate[1]+20);
        border.changeColor(original);
    }

    /**
     * El metodo responsable de que shy aparezca y desaparezca
     * @wheelVisible booleano que dice si su rueda es visible (para saber como se comporta el borde)
     */
    public void select(boolean wheelVisible){
        if (wheelVisible){
            if(!isShy){
                body.changeColor(original);
            }
            else{
                body.changeColor("white");
            }
            border.makeVisible();
            super.makeVisible();
            isShy=!isShy;
        }
    }
    
    @Override
    public void makeVisible(){
        if (isShy){
            body.changeColor("white");
        }
        else{
            body.changeColor(original);
        }
        border.makeVisible(); //orden importa
        super.makeVisible();
    }
    
    @Override
    public void makeInvisible(){
        super.makeInvisible();
        border.makeInvisible();
    }
    
    @Override
    public void moveHorizontal(int distance){
        border.moveHorizontal(distance);
        super.moveHorizontal(distance);
    }
    
    @Override
    public void moveVertical(int distance){
        border.moveVertical(distance);
        super.moveVertical(distance);
    }
    
    @Override
    public void move(int horizontal, int vertical){
        border.moveVertical(vertical);
        border.moveHorizontal(horizontal);
        super.move(horizontal, vertical);
    }
}
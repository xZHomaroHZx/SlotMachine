import java.util.ArrayList;
import java.util.Random;
/**
 * Ruedas de SlotMachine
 * 
 * @author  Juan Esteban Mendoza Acero, Omar Santiago Perez
 * @version 5.0  (24 de octubre 2026)
 */
public class Wheel{
    protected int num;
    protected int[] coordinate;
    protected boolean isVisible;
    protected Circle body;
    protected ArrayList<Symbol> symbols;
    protected Symbol currentSymbol;
    protected boolean locked;
    protected String type="normal";
    protected Random random;
    /**
     * El contructor que las hace con un catalogo predeterminado de simbolos y maneja posiciones graficas
     * 
     * @param  num  el numero de la rueda (posicion)
     */
    public Wheel(int num){
        random=new Random();
        this.num=num;
        coordinate=new int[2];
        coordinate[0]=100 + 175*(num-1);
        coordinate[1]=100;
        isVisible=false;
        body=new Circle();
        body.changeSize(72);
        body.changeColor("white");
        body.moveHorizontal(coordinate[0]);
        body.moveVertical(coordinate[1]);
        symbols=new ArrayList<Symbol>();
    }

    /**
     * Hace visible la rueda
     * 
     */
    public void makeVisible(){
        isVisible=true;
        body.makeVisible();
        if (currentSymbol!=null){ //por si fuera null el symbol (por si acaso)
            currentSymbol.makeVisible();
        }
    }

    /**
     * Hace invisible la rueda
     */
    public void makeInvisible(){
        isVisible=false;
        body.makeInvisible();
        if (currentSymbol!=null){
            currentSymbol.makeInvisible();
        }
    }

    /**
     * Cambia el simbolo actual (que muestra) la rueda
     * 
     * @param   newSymbol   el nuevo simbolo para mostrar
     */
    public void updateSymbol(Symbol newSymbol){
        if (currentSymbol!=null){
            currentSymbol.makeInvisible(); //si no fallaria si hace makeVisible a un null
        }
        currentSymbol=newSymbol;
        if (currentSymbol!=null){
            if (isVisible){
                currentSymbol.select(isVisible);
            }
        }
    }

    /**
     * Devuelve el numero de la rueda
     * 
     * @return     el numero de la rueda
     */
    public int getNumber(){
        return num;
    }

    /**
     * Nos devuelve el simbolo que muestra la rueda actualmente (color)
     * 
     * @return     el simbolo que muestra la rueda
     */
    public String getCurrentSymbol() throws SlotMachineException{
        if (symbols.size()==0){
            throw new SlotMachineException(SlotMachineException.NO_SYMBOLS);
        }
        return currentSymbol.getColor();
    }
    
    /**
     * Nos da todos los simbolos que la rueda puede mostrar
     * 
     * @return     todos los simbolos disponibles para la rueda
     */
    public ArrayList<Symbol> getSymbols(){
        return symbols;
    }
    
    /**
     * Añade un symbol a la rueda y retorna true si pudo.
     * 
     * @param color el color del nuevo symbol
     * @return booleano que dice si pudo añadirlo
     */
    public boolean addSymbol(String color){
        if (symbols.size()==0){
            symbols.add(new Symbol(color,coordinate[0],coordinate[1]));
            currentSymbol=symbols.get(0);
            if (isVisible){
                currentSymbol.makeVisible();
            }
        }
        else{
            for (int i=0; i<symbols.size(); i++){
                if (symbols.get(i).getColor().equals(color)){
                    return false; //ya estaba
                }
            }
            symbols.add(new Symbol(color,coordinate[0],coordinate[1]));
        }
        return true;
    }
    
    /**
     * Añade un simbolo especial a la rueda
     * @param type el tipo de rueda (shy o ephemeral)
     * @param color el color de la rueda
     * @return booleano que confirma si pudo añadirla
     */
    public boolean addSymbol(String type, String color){
        Symbol newSymbol=null;
        if (type.equals("normal")){
            newSymbol=new Symbol(color,coordinate[0],coordinate[1]);
        }
        else if (type.equals("ephemeral")){
            newSymbol=new Ephemeral(color,coordinate[0],coordinate[1]);
        }
        else if (type.equals("shy")){
            newSymbol=new Shy(color,coordinate[0],coordinate[1]);
        }
        if (newSymbol==null){
            return false;
        }
        if (symbols.size()==0){
            symbols.add(newSymbol);
            currentSymbol=symbols.get(0);
        }
        else{
            for (int i=0; i<symbols.size(); i++){
                if (symbols.get(i).getColor().equals(color)){
                    return false; //ya estaba ese color
                }
            }
            symbols.add(newSymbol);
        }
        return true;
    }
    
    /**
     * Elimina un symbol de la rueda, si el symbol eliminado es el actual, muestra el siguiente.
     * No es un booleano porque aunque no elimine nada es porque no estaba en primer lugar (en cuyo caso esta ok)
     * 
     * @param color el color del symbol a eliminar
     */
    public void delSymbol(String color){
        for (int i=0; i<symbols.size(); i++){
            if (symbols.get(i).getColor().equals(color)){
                boolean isCurrent=symbols.get(i)==currentSymbol; //revisa si es el que mustra ahora
                if (isCurrent){
                    currentSymbol.makeInvisible();
                }
                symbols.remove(i);
                if (isCurrent){
                    if (symbols.size()>0){
                        if (i>=symbols.size()){ //si era el ultimo en symbols muestra el siguente (primero)
                            i=0;
                        }
                        currentSymbol=symbols.get(i);
                        if (isVisible){
                            currentSymbol.makeVisible();
                        }
                    }
                    else{
                        currentSymbol=null; //elimino el unico symbol
                    }
                }
            }
        }
    }
    
    /**
     * Pone un symbol especifico como el actual.
     * 
     * @param color el color del symbol deseado
     * @return booleano de si pudo hacerlo (false si el color no existe)
     */
    public boolean placeSymbol(String color){
        for (int i=0; i<symbols.size(); i++){
            if (symbols.get(i).getColor().equals(color)){
                updateSymbol(symbols.get(i));
                return true;
            }
        }
        return false;
    }
    
    /**
     * Hace spin de la rueda a una posicion especifica (posicion de symbols)
     * SlotMachine fue la que giro y Wheel solo lo cambia
     * 
     * @param position la posicion del symbol que toco
     */
    public void spin(int position){
        updateSymbol(symbols.get(position));
    }
    
    /**
     * Mueve la rueda a una posicion especifica, moviendo todos los simbolos de la rueda tambien.
     * 
     * @param x la nueva posicion horizontal de la rueda
     * @param y la nueva posicion vertical de la rueda
     */
    public void moveTo(int x,int y){
        int horizontal=x-coordinate[0]; //Si esta en 1000, 748 y quiero ir a 490, 809 entonces hago 490-1000 (-510) y 809-748 (61) y me muevo esos deltas
        int vertical=y-coordinate[1];
        body.moveHorizontal(horizontal);
        body.moveVertical(vertical);
        for (Symbol symbol: symbols){
            symbol.moveHorizontal(horizontal);
            symbol.moveVertical(vertical);
        }
        coordinate[0]=x;
        coordinate[1]=y;
    }
    
    /**
     * Cambia el numero de la rueda
     *
     * @param number el nuevo numero
     */
    public void setNumber(int number){
        num=number;
    }
    
    /**
     * Retorna las coordenadas de la rueda (x, y)
     *
     * @return las coordenadas de la rueda
     */
    public int[] getCoordinates(){
        return coordinate;
    }
    
    /**
     * Bloquea la rueda.
     */
    public void lock(){
        locked=true;
    }
    
    
    /**
     * Desbloquea la rueda.
     */
    public void unlock(){
        locked=false;
    }
    
    
    /**
     * Mira si la rueda esta bloqueada
     *
     * @return el booleano que mira si la rueda esta bloqueada
     */
    public boolean getLocked(){
        return locked;
    }
    
    /**
     * Retorna la posicion del simbolo actual dentro del ArrayList symbols.
     *
     * @return la posicion del simbolo actual
     */
    public int getCurrentSymbolPosition(){
        for (int i=0; i<symbols.size(); i++){
            if (symbols.get(i)==currentSymbol){
                return i;
            }
        }
        return -1; //si Wheel no tiene symbols, en cuyo caso -1 seria error (no es como python que escoje el ultimo)
    }
    
    /**
     * Avanza la rueda un solo paso (visible)
     */
    public void spinVisible(int steps) throws SlotMachineException{
        if (symbols.size()>0){
            int position=getCurrentSymbolPosition();
            if (position==-1){
                throw new SlotMachineException(SlotMachineException.INVALID_CURRENT_SYMBOL);
            }
            if (steps>0){
                for (int i=0; i<steps; i++){
                    position=position+1;
                    if (position>=symbols.size()){
                        position=0;
                    }
                    updateSymbol(symbols.get(position));
                }
            }
        }
        else{
            throw new SlotMachineException(SlotMachineException.NO_SYMBOLS);
        }
    }
    
    /**
     * Retrocede la rueda un solo paso.
     */
    public void spinVisibleBack(int steps) throws SlotMachineException{
        if (symbols.size()>0){
            int position=getCurrentSymbolPosition();
            if (position==-1){
                throw new SlotMachineException(SlotMachineException.INVALID_CURRENT_SYMBOL);
            }
            if (steps>0){
                for (int i=0; i<steps; i++){
                    position=position-1;
                    if (position<0){
                        position=symbols.size()-1;
                    }
                    updateSymbol(symbols.get(position));
                }
            }
        }
        else{
            throw new SlotMachineException(SlotMachineException.NO_SYMBOLS);
        }
    }
    
    /**
     * Gira la rueda una cantidad determinada de pasos (invisible)
     *
     * @param steps cantidad de posiciones que se desea avanzar o retroceder
     */
    public void spinInvisible(int steps) throws SlotMachineException{
        if (symbols.size()>0){
            int position=getCurrentSymbolPosition();
            if (position==-1){
                throw new SlotMachineException(SlotMachineException.INVALID_CURRENT_SYMBOL);
            }
            position=(position+steps)%symbols.size();
            if (position<0){
                position=position+symbols.size();
            }
            updateSymbol(symbols.get(position));
        }
        else{
            throw new SlotMachineException(SlotMachineException.NO_SYMBOLS);
        }
    }
    
    /**
     * Retorna el tipo de rueda (String)
     * @return el tipo de rueda
     */
    public String getType(){
        return type;
    }
    
    /**
     * Metodo responsable de girar 
     */
    public void spinRandom() throws SlotMachineException{
        if (symbols.size()==0){
            throw new SlotMachineException(SlotMachineException.NO_SYMBOLS);
        }
        int position=random.nextInt(symbols.size());
        updateSymbol(symbols.get(position));
    }
}

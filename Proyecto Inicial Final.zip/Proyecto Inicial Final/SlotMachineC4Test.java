import static org.junit.Assert.*;
import org.junit.After;
import org.junit.Before;
import org.junit.Test;

/**
 * The test class SlotMachineC2Test.
 *
 * @author  Juan Esteban Mendoza Acero, Omar Santiago Perez
 * @version 5.0
 */
public class SlotMachineC4Test{
    /**
     * Sets up the test fixture.
     *
     * Called before every test case method.
     */
    @Before
    public void setUp(){
    }

    @Test //hace un slotmachine, pone la primera rueda en magenta y añade una en el lugar de la primera (deberia correrla)
    public void shouldAddWheel(){ //no tiene acceso a wheels para ver numeros de rueda (a menos que la haga publica)
        SlotMachine sm=new SlotMachine();
        sm.placeSymbol(1,"magenta");
        sm.addWheel(1);
        sm.addSymbol(1, "blue");
        sm.addSymbol(1, "magenta");
        sm.addSymbol(1, "yellow");
        String[] configuration=sm.configuration();
        assertEquals(4, configuration.length);
        assertEquals("blue", configuration[0]);
        assertEquals("magenta", configuration[1]);
        assertEquals("blue", configuration[2]);
        assertTrue(sm.ok());
    }

    @Test //Mira que la longitud inicial sea 2, borra 1 y ve que sea 1 efectivamente
    public void shouldDeleteWheel(){
        SlotMachine sm=new SlotMachine();
        assertEquals(3,sm.configuration().length);
        sm.delWheel(2);
        assertEquals(2,sm.configuration().length);
        assertTrue(sm.ok());
    }

    @Test
    public void shouldSwapWheels(){//crea, cambia a magenta la primera, verifica, cambia y verifica que el magenta ahora sea el segundo
        SlotMachine sm=new SlotMachine();
        sm.placeSymbol(1,"magenta");
        assertEquals("magenta",sm.configuration()[0]);
        sm.swap(1,2);
        assertEquals("magenta",sm.configuration()[1]);
        assertEquals("blue",sm.configuration()[0]);
        assertTrue(sm.ok());    
    }

    @Test
    public void shouldLockWheel(){//crea, lock rueda 1, hace spin de esa rueda (deberia fallar)
        SlotMachine sm=new SlotMachine();
        sm.lock(1);
        sm.spin(1);
        assertFalse(sm.ok());
    }

    @Test
    public void shouldUnlockWheel(){//crea 1, bloquea rueda 1, mira que falle, la desbloquea, spin a esa rueda (deberia dar true en ok)
        SlotMachine sm=new SlotMachine();
        sm.lock(1);
        sm.spin(1);
        assertFalse(sm.ok());
        sm.unlock(1);
        sm.spin(1);
        assertTrue(sm.ok());
    }

    @Test
    public void shouldAddSymbol(){//crea, mira que todos los distinct current sean 1
        SlotMachine sm=new SlotMachine();
        assertEquals(1, sm.distinctSymbols()); 
        sm.addSymbol(1, "tomato");
        sm.placeSymbol(1, "tomato");
        assertEquals(2, sm.distinctSymbols());
        assertTrue(sm.ok());
    }

    @Test
    public void shouldDeleteSymbol(){//crea, verifica que sea solo 1 distinct, elimina el actual (azul) de las ruedas y mira que sean 1 igual y que sea el magenta
        SlotMachine sm=new SlotMachine();
        assertEquals(1, sm.distinctSymbols());
        sm.delSymbol("blue");
        assertEquals(1, sm.distinctSymbols());
        assertEquals("magenta",sm.configuration()[0]);
        assertTrue(sm.ok());
    }

    @Test //I
    public void shouldPlaceSymbol(){ //crea, mira que sea azul la primera rueda, lo cambia a amarillo y mira que se haya cambiado 
        SlotMachine sm=new SlotMachine();
        assertEquals("blue",sm.configuration()[0]);
        sm.placeSymbol(1, "yellow");
        assertEquals("yellow",sm.configuration()[0]);
        assertTrue(sm.ok());
    }

    @Test //e?
    public void shouldSpinWheel(){
        SlotMachine sm=new SlotMachine();             
        assertEquals("blue",sm.configuration()[0]);
        sm.spin(1);
        String[] posconf=sm.configuration();
        assertTrue(posconf[0].equals("blue") || posconf[0].equals("yellow") || posconf[0].equals("magenta"));
        assertTrue(sm.ok());  
    }

    @Test
    public void shouldSpinWheelSteps(){ //crea, verifica que sea blue primero y despues gira 4 steps (deberia ser magenta (b>m>y>b>m))
        SlotMachine sm=new SlotMachine();             
        assertEquals("blue",sm.configuration()[0]);
        sm.spin(1, 4);
        assertEquals("magenta", sm.configuration()[0]);
        assertTrue(sm.ok());
    }

    @Test
    public void shouldSpinWheelsConfiguration(){//crea, revisa que todo sea azul, pone el orden en magenta, yellow y blue y revisa esto.
        SlotMachine sm=new SlotMachine();
        String[] preconf=sm.configuration();
        for (int i=0; i<3; i++){
            assertEquals("blue",preconf[i]);
        }
        String[] testConf= new String[] {"magenta", "yellow", "blue"};
        sm.spin(testConf);
        assertTrue(sm.ok());
        String[] posconf=sm.configuration();
        assertEquals("magenta",posconf[0]);
        assertEquals("yellow",posconf[1]);
        assertEquals("blue",posconf[2]);
        assertTrue(sm.ok());
    }

    @Test
    public void shouldReturnSymbols(){//crea, mira los simbolos actuales, luego añade tomato a la rueda 2 y silver a la 1, revisa que los lea en el orden debido
        SlotMachine sm=new SlotMachine(); 
        String[] testSymbols1= new String[] {"blue", "magenta", "yellow"};
        assertEquals(testSymbols1, sm.symbols());
        sm.addSymbol(2, "tomato");
        sm.addSymbol(1, "silver");
        String[] testSymbols2= new String[] {"blue", "magenta", "yellow", "silver", "tomato"};
        assertEquals(testSymbols2, sm.symbols());
    }

    @Test
    public void shouldReturnDistinctSymbols(){//crea, revisa que todos sea azules (distinctSymbol=1), luego pone 1 y 2 en diferentes y revisa que sean 3 distintos
        SlotMachine sm=new SlotMachine(); 
        assertEquals(1, sm.distinctSymbols());
        sm.placeSymbol(1, "magenta");
        sm.placeSymbol(2, "yellow");
        assertEquals(3 , sm.distinctSymbols());
    }

    @Test
    public void shouldReturnConfiguration(){//crea mira si son todos azules
        SlotMachine sm=new SlotMachine(); 
        String[] testConf1= new String[] {"blue", "blue", "blue"};
        assertEquals(testConf1, sm.configuration());
        assertTrue(sm.ok());
        sm.placeSymbol(1, "magenta");
        sm.placeSymbol(2, "yellow");
        String[] testConf2= new String[] {"magenta", "yellow", "blue"};
        assertEquals(testConf2, sm.configuration());
        assertTrue(sm.ok());
    }

    @Test
    public void shouldRecognizeJackpot(){//crea y mira si es jackpot de una (inician todos azules), cambia la rueda 2 a yellow y mira que no de jackpot
        SlotMachine sm=new SlotMachine();
        assertTrue(sm.isJackpot());
        sm.placeSymbol(2, "yellow");
        assertFalse(sm.isJackpot());
    }


    @Test
    public void shouldReturnOk(){//crea, elimina las 3 ruedas y verifica que pueda, intenta eliminar otra y deberia fallar (ok=false)
        SlotMachine sm=new SlotMachine();
        sm.delWheel(1);
        assertTrue(sm.ok());
        sm.delWheel(1);
        assertTrue(sm.ok());
        sm.delWheel(1);
        assertTrue(sm.ok());
        sm.delWheel(1);
        assertFalse(sm.ok());
    }
    

    @Test
    public void shouldSpinLeftyBySteps(){//crea, pone una lefty con 2 simbolos, pone la tercera rueda en magenta, hace spin de lefty (deberia copiar magenta)
        SlotMachine sm=new SlotMachine();
        sm.addWheel("lefty", 4);
        sm.addSymbol(4, "blue");
        sm.addSymbol(4, "magenta"); 
        sm.placeSymbol(3,"magenta");
        sm.spin(4, 2);
        assertEquals("magenta",sm.configuration()[3]);
        assertTrue(sm.ok());
    }
    
    @Test
    public void shouldNotLockRebel(){//crea una slotmachine, añade una rebelde, intenta lock y deberia fallar
        SlotMachine sm=new SlotMachine();
        sm.addWheel("rebel", 4);
        sm.lock(4);
        assertFalse(sm.ok());
    }
    
    @Test
    public void shouldNotSwapRebel(){//crea una slotmachine, pone una rebelde y falla un swap
        SlotMachine sm=new SlotMachine();
        sm.addWheel("rebel", 4);
        sm.swap(1, 4);
        assertFalse(sm.ok());
    }
    
    @Test
    public void shouldNotDeleteRebel(){//crea una slotmachine, pone una rebel y intenta borrarla (falla)
        SlotMachine sm=new SlotMachine();
        sm.addWheel("rebel", 4);
        sm.delWheel(4);
        assertFalse(sm.ok());
    }
    
    /**
     * Tears down the test fixture.
     *
     * Called after every test case method.
     */
    @After
    public void tearDown(){
    }
}
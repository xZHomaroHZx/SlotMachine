import java.awt.*;
import java.awt.geom.*;
/**
 * La clase abstracta se shape (es Figure porque Shape es otra cosa entonces tiene conflicto el nombre)
 * 
 * @author Juan Esteban Mendoza, Omar Santiago Perez
 * @version 2.0
 */
public abstract class Figure{
    protected int xPosition;
    protected int yPosition;
    protected String color;
    protected boolean isVisible;

    public void makeVisible(){
        isVisible=true;
        draw();
    }

    public void makeInvisible(){
        erase();
        isVisible=false;
    }

    public void moveRight(){
        moveHorizontal(20);
    }

    public void moveLeft(){
        moveHorizontal(-20);
    }

    public void moveUp(){
        moveVertical(-20);
    }

    public void moveDown(){
        moveVertical(20);
    }

    public void moveHorizontal(int distance){
        erase();
        xPosition+=distance;
        draw();
    }

    public void moveVertical(int distance){
        erase();
        yPosition+=distance;
        draw();
    }

    public void slowMoveHorizontal(int distance){
        int delta;
        if(distance<0){
            delta=-1;
            distance=-distance;
        }
        else{
            delta=1;
        }
        for(int i=0;i<distance;i++){
            xPosition+=delta;
            draw();
        }
    }

    public void slowMoveVertical(int distance){
        int delta;
        if(distance<0){
            delta=-1;
            distance=-distance;
        }
        else{
            delta=1;
        }
        for(int i=0;i<distance;i++){
            yPosition+=delta;
            draw();
        }
    }

    public void changeColor(String newColor){
        color=newColor;
        draw();
    }

    protected abstract void draw();

    protected abstract void erase();
}
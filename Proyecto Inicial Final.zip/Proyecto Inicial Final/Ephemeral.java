
/**
 * El simbolo ephemeral (cada vez que es seleccionado disminuye en tamaño)
 * 
 * @author Juan Esteban Mendoza Acero, Omar Santiago Perez
 * @version 1.0 (24 de octubre de 2026)
 */
public class Ephemeral extends Symbol{
    private Triangle border;
    private int borderHeight;
    private int borderWidth;
    /**
     * Constructor del simbolo ephemeral
     * @param color el color del simbolo
     * @xPosition la posicion que le corresponde en eje x
     * @yPosition la posicion que le corresponde en eje y
     */
    public Ephemeral(String color, int xPosition, int yPosition){
        super(color,xPosition,yPosition);
        borderHeight=34;
        borderWidth=34;
        border= new Triangle();
        border.changeSize(borderHeight, borderWidth);
        border.moveHorizontal(coordinate[0]+34);
        border.moveVertical(coordinate[1]+20);
        border.changeColor("black");
    }

    /**
     * El metodo que es responsable de que cada vez que salga el simbolo disminuya de tamaño
     * @param wheelVisible booleano que dice si la rueda es visible (para saber como comportarse)
     */
    public void select(boolean wheelVisible){
        if (wheelVisible){
            int[] measures=getMeasures();
            int height=measures[0];
            int width=measures[1];
            if(height>1 && width>1){
                borderHeight-=1;
                borderWidth-=1;
                changeSize(height-1,width-1);
                border.changeSize(borderHeight, borderWidth);
            }
            makeVisible();
        }
    }
    
    @Override
    public void makeVisible(){
        border.makeVisible();
        super.makeVisible();
    }
    
    @Override
    public void makeInvisible(){
        super.makeInvisible();
        border.makeInvisible();
    }
    
    @Override
    public void moveHorizontal(int distance){
        border.moveHorizontal(distance);
        super.moveHorizontal(distance);
    }
    
    @Override
    public void moveVertical(int distance){
        border.moveVertical(distance);
        super.moveVertical(distance);
    }
    
    @Override
    public void move(int horizontal, int vertical){
        border.moveVertical(vertical);
        border.moveHorizontal(horizontal);
        super.move(horizontal, vertical);
    }
}
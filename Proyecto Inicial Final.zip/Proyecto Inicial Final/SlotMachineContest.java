
/**
 * La clase encargada de resolver el problema de la maraton (solo usa distinctSymbols y spin por steps (y makeVisible en el caso de simulate)).
 * 
 * @author Juan Esteban Mendoza, Omar Santiago Perez
 * @version 1.0
 */
public class SlotMachineContest{
    /**
     * Resuelve una slotmachine aleatoria (pero con los mismos simbolos compartidos entre todas las ruedas.
     * Para ello nos guiamos en la solucion propuesta en este video: https://www.youtube.com/watch?v=gYkF0kZ1bkE de ahi lo dividimos en 3 fases.
     * Primera fase: Poner todas las ruedas en un simbolo diferente (spin +1 hasta que distinctsymbols aumente o lo haya hecho n veces).
     * Segunda fase: Se hallan los desfases de todas las ruedas menos la primera, esta es la de referencia.
     * Se suma 1 posicion a la rueda 1, y se le va restando 1 a las otras hasta que distinct sea n de nuevo (sabemos que esa rueda esta a offset spins de la primera entonces), se revierte si no es la adecuada.
     * Tercera fase: Ya teniendo la lista de los offset, se arma la respuesta (primera posicion tiene el simbolo que todas adoptaran) y se retorna.
     * (Perdon si quedo larga la documentacion pero era para que fuera lo mas entendible posible)
     * 
     * @param n El numero de ruedas y simbolos que se quiere tener para resolver.
     * @return Una lista de listas de n-1 listas, donde cada sublista esta compuesta de una rueda y su desfase (comparado con la primera (por eso n-1)).
     */
    public int[][] solve(int n){
        SlotMachine machine=new SlotMachine(n);
        //1
        for (int wheel=2; wheel<=n && machine.distinctSymbols()<n; wheel++){ //para recorrer todas las ruedas a partir de 2
            int before=machine.distinctSymbols();
            int current=before;
            int steps=0;
            while (current<=before && steps<n){ //para cambiar el simbolo de esa rueda a uno difernte (si distinct aumenta o si lo hace n veces (ya estaba en el distinto))
                machine.spin(wheel, 1);
                current = machine.distinctSymbols();
                steps++;
            }
        }
        //2
        int[] offsets=new int[n]; //se pone todo en -1 (si es -1 es que no lo sabemos), se maneja por la posicion de la rueda
        for (int i=0; i<n; i++){
            offsets[i]=-1;
        }
        offsets[0]=n;
        for (int offset=1; offset<n; offset++){ //va viendo a que posicion corresponde cada desfase desde 1 (0 es de rueda 1)
            machine.spin(1,1);
            boolean found=false; //para no usar un break, cuando se encuentre la rueda que tiene ese offset
            int cont=2; //para ir contando las ruedas (ir viendo cual tiene el desfase)
            while (!found && cont<=n){
                if (offsets[cont-1]==-1){ //si no se sabe el offset de esa rueda
                    machine.spin(cont,-1);
                    if (machine.distinctSymbols()==n){ //esa rueda tiene el offset correspondiente
                        offsets[cont-1]=offset;
                        found=true;
                    }
                    else{ //s revierte porque si no se desarma todo
                        machine.spin(cont,1);
                    }
                }
                cont=cont+1;
            }
        }
        //3
        int[][] answer=new int[n-1][2];
        for (int wheel=2;wheel<=n;wheel++){
            answer[wheel-2][0]=wheel;
            answer[wheel-2][1]=offsets[wheel-1];
        }
        return answer;
    }
    
    /**
     * Hace lo mismo que solve pero ahora visible (es un solve diferente), basado en el mismo video.
     *
     * @param n El numero de ruedas y simbolos que se quiere tener para simular la respuesta.
     */
    public void simulate(int n){
        SlotMachine machine=new SlotMachine(n);
        machine.makeVisible();
        //1
        for (int wheel=2; wheel<=n && machine.distinctSymbols()<n; wheel++){
            int before=machine.distinctSymbols();
            int current=before;
            int steps=0;
            while (current<=before && steps<n){
                machine.spin(wheel,1);
                current=machine.distinctSymbols();
                steps++;
            }
        }
        //2
        int[] offsets=new int[n]; 
        for (int i=0; i<n; i++){
            offsets[i]=-1;
        }
        offsets[0]=n;
        for (int offset=1; offset<n; offset++){
            machine.spin(1,1);
            boolean found=false;
            int cont=2;
            while (!found && cont<=n){
                if (offsets[cont-1]==-1){
                    machine.spin(cont,-1);
                    if (machine.distinctSymbols()==n){
                        offsets[cont-1]=offset;
                        found=true;
                    }
                    else{
                        machine.spin(cont,1);
                    }
                }
                cont=cont+1;
            }
        }
        for (int wheel=2; wheel<=n; wheel++){
            machine.spin(wheel,-offsets[wheel-1]);
        }
    }
}
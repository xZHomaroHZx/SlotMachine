import java.util.ArrayList;
import java.util.Random;

/**
 * Rueda que cambia de color aleatoriamente con cada accion.
 *
 * @author Juan Esteban Mendoza, Omar Santiago Perez
 * @version 1.0 (24 de octubre de 2026)
 */
public class Rainbow extends Wheel{
    private CSSColors colors;
    private Random random;
    private ArrayList<String> available;
    /**
     * Constructor de la rueda Rainbow
     * @param num numero de la rueda
     */
    public Rainbow(int num){
        super(num);
        type="rainbow";
        colors=new CSSColors();
        random=new Random();
        available=new ArrayList<String>();
        for (String color: colors.getColors()){
            available.add(color);
        }
    }

    /**
     * Cambia el color de la rueda al azar.
     * Si esta visible, actualiza tambien el simbolo actual (si tiene)
     */
    private void changeRandomColor(){
        String newColor=available.get(random.nextInt(available.size()));
        body.changeColor(newColor);
        if (isVisible && symbols.size()>0){
            currentSymbol.makeVisible();
        }
    }

    /**
     * Cambia el simbolo actual y el color de la rueda
     * @param newSymbol el nuevo simbolo
     */
    @Override
    public void updateSymbol(Symbol newSymbol){
        super.updateSymbol(newSymbol);
        changeRandomColor();
    }

    /**
     * Añade un simbolo y cambia el color
     * @param color el color del simbolo
     * @return boolano que dice si pudo añadirlo
     */
    @Override
    public boolean addSymbol(String color){
        boolean added=super.addSymbol(color);
        if (added){
            changeRandomColor();
        }
        return added;
    }

    /**
     * Añade un simbolo de un tipo especifico y cambia el color
     * @param type tipo de simbolo para añadir
     * @param color el color del simbolo
     * @return booleano que dice si pudo añadirlo
     */
    @Override
    public boolean addSymbol(String type, String color){
        boolean added=super.addSymbol(type,color);
        if (added){
            changeRandomColor();
        }
        return added;
    }

    /**
     * Elimina un simbolo y cambia el color
     * @param color el color del simbolo que se elimina
     */
    @Override
    public void delSymbol(String color){
        int previousSize=symbols.size();
        super.delSymbol(color);
        if (symbols.size()<previousSize){
            changeRandomColor();
        }
    }

    /**
     * Bloquea la rueda y cambia el color
     */
    @Override
    public void lock(){
        super.lock();
        changeRandomColor();
    }

    /**
     * Desbloquea la rueda y cambia el color
     */
    @Override
    public void unlock(){
        super.unlock();
        changeRandomColor();
    }
}
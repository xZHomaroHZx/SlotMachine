/**
 * Los simbolos de las ruedas de SlotMachine
 * 
 * @author  Juan Esteban Mendoza Acero, Omar Santiago Perez
 * @version 5.0  (24 de octubre de 2026)
 */
public class Symbol{
    protected String color;
    protected Triangle body;
    protected int[] coordinate;
    /**
     * El constructor del simbolo
     * a
     * @param  color    el color del simbolo
     * @param xPosition La posicion en x del simbolo
     * @param yPosition La posicion en y del simbolo
     */
    public Symbol(String color, int xPosition, int yPosition){
        this.color=color;
        coordinate=new int[2];
        coordinate[0]=xPosition;
        coordinate[1]=yPosition;
        body=new Triangle();
        body.moveHorizontal(coordinate[0]+34);
        body.moveVertical(coordinate[1]+22);
        body.changeColor(color);
    }

    public String getColor(){
        return color;
    }

    /**
     * Nos dice si 2 simbolos son iguales (por su color)
     * @return  el booleano que determina esto
     */
    public boolean equals(Symbol other){
        return color.equals(other.color);
    }
    
    /**
     * Hace visible el simbolo
     */
    public void makeVisible(){
        body.makeVisible();
    }

    /**
     * Hace invisible el simbolo
     */
    public void makeInvisible(){
        body.makeInvisible();
    }

    /**
     * Mueve horizontalmente el simbolo
     * 
     * @param distance  la distancia a mover en x
     */
    public void moveHorizontal(int distance){
        body.moveHorizontal(distance);
        coordinate[0]=coordinate[0]+distance;
    }

    /**
     * Mueve verticalmente el simbolo (depende del tipo)
     * 
     * @param distance  la distancia a mover en y
     */
    public void moveVertical(int distance){
        body.moveVertical(distance);
        coordinate[1]=coordinate[1]+distance;
    }

    /**
     * Mueve el simbolo a una posicion en el canvas (no moveTo porque Wheel calcula el delta por el entonces es un movimiento simple)
     * 
     * @param x la nueva posicion horizontal del simbolo
     * @param y la nueva posicion vertical del simbolo
     */
    public void move(int horizontal,int vertical){
        body.moveHorizontal(horizontal);
        body.moveVertical(vertical);
        coordinate[0]=coordinate[0]+horizontal;
        coordinate[1]=coordinate[1]+vertical;
    }
    
    /**
     * 
     */
    public void select(boolean wheelVisible){
        if (wheelVisible){
            makeVisible();
        }
    }
    
    /**
     * 
     */
    protected void changeSize(int height, int width){
        body.changeSize(height,width);
    }

    /**
     * 
     */
    protected int[] getMeasures(){
        return body.getMeasures();
    }
}
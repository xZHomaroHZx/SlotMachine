
/**
 * La clase para excepciones de Slotmachine (wow).
 * 
 * @Juan Esteban Mendoza, Omar Santiago Perez
 * @version 1.0 (24 de octubre de 2026)
 */
public class SlotMachineException extends Exception{
    public static final String REBEL_CANNOT_BE_LOCKED="No puedes bloquear una rueda rebelde.";
    public static final String NO_WHEELS_TO_LOCK="No hay ruedas para bloquear.";
    public static final String WHEEL_LOCKED="La rueda esta bloqueada.";
    public static final String NO_WHEELS_TO_SPIN="No hay ruedas para girar.";
    public static final String NO_SYMBOLS="Alguna rueda no tiene simbolos.";
    public static final String INVALID_CURRENT_SYMBOL="El simbolo actual no existe."; //por si acaso
    public static final String LEFTY_CANT_COPY="Lefty no tiene el simbolo para copiar";
    public static final String LEFTY_CANT_COPY_NOTHING="Lefty no puede copiar un simbolo que no existe.";
    public SlotMachineException(String message){
        super(message);
    }
}
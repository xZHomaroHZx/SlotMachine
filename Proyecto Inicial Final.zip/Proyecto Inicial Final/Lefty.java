
/**
 * Rueda que al girar copia el simbolo de su izquierda
 * 
 * @author Juan Esteban Mendoza, Omar Santiago Perez
 * @version 1.0 (24 de octubre de 2026)
 */
public class Lefty extends Wheel{
    /**
     *  El contructor de lefty
     *  @param num el numero que le corresponde a la rueda
     */
    public Lefty(int num){
        super(num);
        type="lefty";
        body.changeColor("gray");
    }
    
    /**
     * Metodo que gira la rueda (necesita la rueda a su izquierda)
     * @param leftWheel la rueda de su izquierda
     * @throws SlotMachineException LEFTY_CANT_COPY si la rueda no tiene el simbolo que debe copiar
     *                              , LEFTY_CANT_COPY_NOTHING si la rueda de la izquierda no tiene simbolos
     */
    public void spinRandom(Wheel leftWheel) throws SlotMachineException{
        if (leftWheel.getSymbols().size()>0){
            Symbol leftSymbol=leftWheel.currentSymbol;
            boolean found=false;
            int position=0;
            for (int i=0; i<symbols.size() && !found; i++){
                if (symbols.get(i).equals(leftSymbol)){
                    found=true;
                    position=i;
                }
            }
            if (found){
                updateSymbol(symbols.get(position));
            }
            else{
                throw new SlotMachineException(SlotMachineException.LEFTY_CANT_COPY);
            }
        }
        else{
            throw new SlotMachineException(SlotMachineException.LEFTY_CANT_COPY_NOTHING);
        }
    }
    
    /**
     * Gira la rueda (solo funciona 1 vez (copia) y luego solo selecciona la misma rueda)
     * @param leftWheel la rueda de su izquierda
     * @param steps la cantidad de pasos que debe hacer (si el simbolo no es diferente solo ve 1)
     */
    public void spinVisible(Wheel leftWheel, int steps) throws SlotMachineException{
        if (steps!=0){
            spinRandom(leftWheel);
            if (steps<0){
                steps*=-1;
            }
            for (int i=1; i<steps; i++){
                currentSymbol.select(isVisible);
            }
        }
    }
    
    /**
     * Gira la rueda (atras para mantener coherencia porque ya estaba antes, entonces para que Lefty sepa que hacer) (solo funciona 1 vez (copia) y luego solo selecciona la misma rueda)
     * @param leftWheel la rueda de su izquierda
     * @param steps la cantidad de pasos que debe hacer (si el simbolo no es diferente solo ve 1)
     */
    public void spinVisibleBack(Wheel leftWheel, int steps) throws SlotMachineException{
        if (steps!=0){
            spinRandom(leftWheel);
            if (steps<0){
                steps*=-1;
            }
            for (int i=1; i<steps; i++){
                currentSymbol.select(isVisible);
            }
        }
    }
    
    /**
     * Gira la rueda de una (a su copia)
     * @param leftWheel la rueda de su izquierda
     * @param steps la cantidad de pasos que debe hacer (si el simbolo no es diferente solo ve 1)
     */
    public void spinInvisible(Wheel leftWheel, int steps) throws SlotMachineException{
        if (steps!=0){
            spinRandom(leftWheel);
        }
    }
}